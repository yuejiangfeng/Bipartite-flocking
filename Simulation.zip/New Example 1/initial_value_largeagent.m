%%%%% Jiangfeng Yue %%%%% 
%%%%%    2025.09    %%%%% 
% Title "Secure Flocking Dynamics of Swarms Over Cooperative-Antagonistic Networks"

% choose initial states
load('initialStates.mat');

% random set
% intial_x11 = ((rand (1,12)*2)-0.5); % Y���� Group 1
% intial_x12 = ((rand (1,12)*2)-1);   % Y���� Group 2
% intial_x1 = [intial_x11,intial_x12];
% 
% intial_x21 = ((rand (1,12)*2)+4); % X���� Group 1
% intial_x22 = ((rand (1,12)*2)-4); % X���� Group 22
% intial_x2 = [intial_x21,intial_x22];
% 
% intial_v11 = ((rand (1,12)*0.02)-0.01);
% intial_v12 = ((rand (1,12)*0.02)-0.01);
% intial_v1 = [intial_v11,intial_v12];
% 
% intial_v21 = ((rand (1,8)*5)-5);
% intial_v211 = ((rand (1,4)*3)); 
% intial_v22 = ((rand (1,8)*5));
% intial_v222 = ((rand (1,4)*3)-3);
% intial_v2 = [intial_v21,intial_v211,intial_v22,intial_v222];
