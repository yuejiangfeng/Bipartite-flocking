%maker_idx = 1:70:length(ScopeData6.signals(1).values);

figure(1)
% plot(state_output.time, state_output.signals.values(:,1),'sk-.','LineWidth',2,'MarkerSize',6,'MarkerIndices',maker_idx);
h1 = plot(out.t, out.x1(:,1),'r-.','LineWidth',1.3); hold on;
plot(out.t, out.x1(:,1:12),'r-.','LineWidth',1.3); hold on;
h2 = plot(out.t, out.x1(:,13),'b-','LineWidth',1.3); hold on;
plot(out.t, out.x1(:,13:24),'b-','LineWidth',1.3); hold on;
%plot(out.t, out.x(:,4:8),'LineWidth',2);hold on;

hold on;
% set(gcf,'Units','centimeter','Position',[5 5 18 14]);

hXLabel = xlabel('Time (sec)');
hYLabel = ylabel('True states $v_i(t)$','interpreter','latex');
set(gca, 'Box', 'on', ...                                        % ��
        'LineWidth',0.5, ...
        'XGrid', 'off', 'YGrid', 'off', ...                      % ����
        'TickDir', 'in', 'TickLength', [.015 .015], ...          % �̶�
        'XMinorTick', 'on', 'YMinorTick', 'on', ...              % С�̶�
        'XColor', [.1 .1 .1],  'YColor',[.1 .1 .1],...           % ��������ɫ
        'XTick', 0:10:90,...                                    % �������̶ȡ���Χ
        'XLim', [0 90],...
        'YTick', -9:2:9,...
        'YLim', [-9 9]);
% �����������������
set(gca, 'FontName', 'Times New Roman')
set([hXLabel, hYLabel], 'FontName','Times New Roman')
set(gca, 'FontSize', 18)
set([hXLabel, hYLabel], 'FontSize', 18, 'FontWeight' ,'normal')
% set(hTitle, 'FontSize', 18, 'FontWeight' ,'bold')
% ����ͼ��
% h=legend('$v_1(t)$','$v_2(t)$','$v_3(t)$','$v_4(t)$','$v_5(t)$','$v_6(t)$','$v_7(t)$',...
%     '$v_8(t)$','NumColumns',2,'interpreter','latex');
% set(h,'FontName','Times New Roman','FontSize',13,'FontWeight','normal');
%set(gcf,'Units','centimeter','Position',[4 4 14 12]);
h = legend([h1,h2],'Group 1','Group 2','interpreter','latex');
set(h,'FontName','Times New Roman','FontSize',12,'FontWeight','normal');
set(gcf,'Units','centimeter','Position',[4 4 22 10]);
grid on;

% axes('Position',[0.18,0.60,0.3,0.3]); % ������ͼ ��򵥵ķ�ʽ
% x=out.t(1401:1601,1);
% y=out.x(1401:1601,:);
% plot(x,y,'linewidth',1.5);
% grid on


figure(2)
% plot(state_output.time, state_output.signals.values(:,1),'sk-.','LineWidth',2,'MarkerSize',6,'MarkerIndices',maker_idx);
h1 = plot(out.t, out.y1(:,1),'r-.','LineWidth',1.3);hold on;
plot(out.t, out.y1(:,1:12),'r-.','LineWidth',1.3);hold on;
h2 = plot(out.t, out.y1(:,13),'b-','LineWidth',1.3);hold on;
plot(out.t, out.y1(:,13:24),'b-','LineWidth',1.3);hold on;

hold on;
% set(gcf,'Units','centimeter','Position',[5 5 18 14]);

hXLabel = xlabel('Time (sec)');
hYLabel = ylabel('Hidden states ${{y}}_i^v(t)$','interpreter','latex');
set(gca, 'Box', 'on', ...                                        % ��
        'LineWidth',0.5, ...
        'XGrid', 'off', 'YGrid', 'off', ...                      % ����
        'TickDir', 'in', 'TickLength', [.015 .015], ...          % �̶�
        'XMinorTick', 'on', 'YMinorTick', 'on', ...              % С�̶�
        'XColor', [.1 .1 .1],  'YColor',[.1 .1 .1],...           % ��������ɫ
        'XTick', 0:10:90,...                                    % �������̶ȡ���Χ
        'XLim', [0 90],...
        'YTick', -12:4:12,...
        'YLim', [-12 12]);
% �����������������
set(gca, 'FontName', 'Times New Roman')
set([hXLabel, hYLabel], 'FontName','Times New Roman')
set(gca, 'FontSize', 18)
set([hXLabel, hYLabel], 'FontSize', 18, 'FontWeight' ,'normal')
% set(hTitle, 'FontSize', 18, 'FontWeight' ,'bold')
% ����ͼ��
% h=legend('${\rm{R}}_1^m(t)$','${\rm{R}}_2^m(t)$','${\rm{R}}_3^m(t)$','${\rm{R}}_4^m(t)$','${\rm{R}}_5^m(t)$','${\rm{R}}_6^m(t)$','${\rm{R}}_7^m(t)$',...
%     '${\rm{R}}_8^m(t)$','NumColumns',2,'interpreter','latex');
% set(h,'FontName','Times New Roman','FontSize',13,'FontWeight','normal');
h = legend([h1,h2],'Group 1','Group 2','interpreter','latex');
set(h,'FontName','Times New Roman','FontSize',12,'FontWeight','normal');
set(gcf,'Units','centimeter','Position',[4 4 22 10]);
grid on;

figure(3)
% plot(state_output.time, state_output.signals.values(:,1),'sk-.','LineWidth',2,'MarkerSize',6,'MarkerIndices',maker_idx);
% plot(out.t, out.pos1,'LineWidth',2);
h1 = plot(out.t, out.pos1(:,1),'r-.','LineWidth',1.3);hold on;
plot(out.t, out.pos1(:,1:12),'r-.','LineWidth',1.3);hold on;
h2 = plot(out.t, out.pos1(:,13),'b-','LineWidth',1.3);hold on;
plot(out.t, out.pos1(:,13:24),'b-','LineWidth',1.3);hold on;

hold on;
% set(gcf,'Units','centimeter','Position',[5 5 18 14]);

hXLabel = xlabel('Time (sec)');
hYLabel = ylabel('True states $r_i(t)$','interpreter','latex');
set(gca, 'Box', 'on', ...                                        % ��
        'LineWidth',0.5, ...
        'XGrid', 'off', 'YGrid', 'off', ...                      % ����
        'TickDir', 'in', 'TickLength', [.015 .015], ...          % �̶�
        'XMinorTick', 'on', 'YMinorTick', 'on', ...              % С�̶�
        'XColor', [.1 .1 .1],  'YColor',[.1 .1 .1],...           % ��������ɫ
        'XTick', 0:10:90,...                                    % �������̶ȡ���Χ
        'XLim', [0 90],...
        'YTick', -120:40:120,...
        'YLim', [-120 120]);
% �����������������
set(gca, 'FontName', 'Times New Roman')
set([hXLabel, hYLabel], 'FontName','Times New Roman')
set(gca, 'FontSize', 18)
set([hXLabel, hYLabel], 'FontSize', 18, 'FontWeight' ,'normal')
% set(hTitle, 'FontSize', 18, 'FontWeight' ,'bold')
% ����ͼ��
% h=legend('$r_1(t)$','$r_2(t)$','$r_3(t)$','$r_4(t)$','$r_5(t)$','$r_6(t)$','$r_7(t)$',...
%     '$r_8(t)$','NumColumns',2,'interpreter','latex');
% set(h,'FontName','Times New Roman','FontSize',13,'FontWeight','normal');
h = legend([h1,h2],'Group 1','Group 2','interpreter','latex');
set(h,'FontName','Times New Roman','FontSize',12,'FontWeight','normal');
set(gcf,'Units','centimeter','Position',[4 4 22 10]);
grid on;

figure(4)
X_true1 = out.pos1(1:901,:);
Y_true1 = out.pos(1:901,:);
len = length(X_true1(:,1));
sample = 40;
% plot(Y_true1(:,1),X_true1(:,1),'color','#008080','linewidth',2);
% hold on
% plot(Y_true1(:,2),X_true1(:,2),'LineStyle','-','color','#0072BD','LineWidth',2);
% hold on
% plot(Y_true1(:,3),X_true1(:,3),'LineStyle','-','color','#D95319','LineWidth',2);
% hold on
% plot(Y_true1(:,4),X_true1(:,4),'LineStyle','-','color','#EDB120','LineWidth',2);
% hold on
% plot(Y_true1(:,5),X_true1(:,5),'LineStyle','-','color','#7E2F8E','LineWidth',2);
% hold on
% plot(Y_true1(:,6),X_true1(:,6),'LineStyle','-','color','#77AC30','LineWidth',2);
% hold on
% plot(Y_true1(:,7),X_true1(:,7),'LineStyle','-','color','#4DBEEE','LineWidth',2);
% hold on
% plot(Y_true1(:,8),X_true1(:,8),'LineStyle','-','color','#A2142F','LineWidth',2);
% hold on
% plot(Y_true1(:,9),X_true1(:,9),'LineStyle','-','color','#4DBEEE','LineWidth',2);
% hold on
% plot(Y_true1(:,10),X_true1(:,10),'LineStyle','-','color','#A2142F','LineWidth',2);
% hold on
for i = 1:24
plot(X_true1(:,i),Y_true1(:,i),'w-','LineWidth',2);
hold on;
end
h1 = plot(X_true1(:,1),Y_true1(:,1),'r-.','LineWidth',1.5);
plot(X_true1(:,[8 9 10 11 12 ]),Y_true1(:,[8 9 10 11 12 ]),'r-.','LineWidth',1.5);
plot(X_true1(:,[2 3 4 5 6 7 ]),Y_true1(:,[2 3 4 5 6 7 ]),'r-','LineWidth',1.5);
h2 = plot(X_true1(:,13),Y_true1(:,13),'b-.','LineWidth',1.5);
plot(X_true1(:,[14 15 19 20 21]),Y_true1(:,[14 15 19 20 21]),'b-.','LineWidth',1.5);
plot(X_true1(:,[16 17 18 22 23 24]),Y_true1(:,[16 17 18 22 23 24]),'b-','LineWidth',1.5);

% % ��������
% xt = [-100 100 100 -100];
% yt1 = [4 4 7 7];
% yt2 = [-6 -6 -3 -3];
% h3 = fill(xt, yt1, [0.8 0.9 1], 'EdgeColor', 'none');hold on;
% fill(xt, yt2, [0.8 0.9 1], 'EdgeColor', 'none');hold on;

A_a=[-5 -9 -5 8 -3 6 -4 5 6 5 -5 -9 -5 8 -3 6 -4 5 6 5 -4 5 6 5];
B=[2 4 3 -4 1 -3 2 -1 2 2 2 4 3 -4 1 -3 2 -1 2 2 2 -1 2 2]*2;
C=[3 4 1 -3 2 -2 1 -3 -1 -1 3 4 1 -3 2 -2 1 -3 -1 -1 1 -3 -1 -1]*2;

for i = 1:24
    y1(i) = intial_x1(i) + C(i);
    y2(i) = intial_x2(i) + B(i);
end

h3 = plot(y2(1:12),y1(1:12),'o', ...
    'color',[1 0.6 0.6], ...          % ǳ��
    'MarkerSize',6, ...
    'LineWidth',1.5, ...
    'MarkerFaceColor',[1 0.6 0.6]);   % ǳ�����

h4 = plot(y2(13:24),y1(13:24),'o', ...
    'color',[0.6 0.8 1], ...          % ǳ��
    'MarkerSize',6, ...
    'LineWidth',1.5, ...
    'MarkerFaceColor',[0.6 0.8 1]);   % ǳ�����

h5 = plot(X_true1(1,1:12),Y_true1(1,1:12),'o','color','r','MarkerSize',6,'LineWidth',1.5);hold on;
h6 = plot(X_true1(1,13:24),Y_true1(1,13:24),'o','color','b','MarkerSize',6,'LineWidth',1.5);hold on;

% plot(X_true1(351,1:12),Y_true1(351,1:12),'p','color','r','MarkerSize',8,'LineWidth',1.5);hold on;
% plot(X_true1(351,13:24),Y_true1(351,13:24),'p','color','b','MarkerSize',8,'LineWidth',1.5);hold on;
% grid on;

%�ϰ���Ĳ���
centerX = 40; centerY = -1.2; radius = 1.5;
centerX1 = 46; centerY1 = -5;

% �����Ƕ�����������x��y����
theta = linspace(0, 2*pi, 100);
x = centerX + radius * cos(theta);
y = centerY + radius * sin(theta);
x1 = centerX1 + radius * cos(theta);
y1 = centerY1 + radius * sin(theta);

% �������Բ
h7 = fill(x, y, [0.8 0.8 0.8]); hold on;
fill(x1, y1, [0.8 0.8 0.8]); hold on;
plot(x, y, 'k-.','linewidth',1.0); hold on;
plot(x1, y1, 'k-.','linewidth',1.0); hold on;

% set(gcf,'Units','centimeter','Position',[5 5 18 14]);

hXLabel = xlabel('$r_i^x(t)$','interpreter','latex');
hYLabel = ylabel('$r_i^y(t)$','interpreter','latex');
set(gca, 'Box', 'on', ...                                        % ��
        'LineWidth',0.5, ...
        'XGrid', 'off', 'YGrid', 'off', ...                      % ����
        'TickDir', 'in', 'TickLength', [.015 .015], ...          % �̶�
        'XMinorTick', 'on', 'YMinorTick', 'on', ...              % С�̶�
        'XColor', [.1 .1 .1],  'YColor',[.1 .1 .1],...           % ��������ɫ
        'XTick', -30:20:50,...                                    % �������̶ȡ���Χ
        'XLim', [-30 50],...
        'YTick', -20:10:20,...
        'YLim', [-20 20]);
% �����������������
set(gca, 'FontName', 'Times New Roman')
set([hXLabel, hYLabel], 'FontName','Times New Roman')
set(gca, 'FontSize', 18)
set([hXLabel, hYLabel], 'FontSize', 18, 'FontWeight' ,'normal')
% set(hTitle, 'FontSize', 18, 'FontWeight' ,'bold')
% ����ͼ��
% h=legend('Agent1','Agent2','Agent3','Agent4','Agent5','Agent6','Agent7',...
%     'Agent8','ITS','IHS','Obs','NumColumns',3,'interpreter','latex');
% set(h,'FontName','Times New Roman','FontSize',12,'FontWeight','normal');
h = legend([h1,h2,h3,h4,h5,h6,h7],'Group 1','Group 2','HS of Group 1','HS of Group 2','IS of Group 1','IS of Group 2','Obstacle','NumColumns',4,'interpreter','latex');
set(h,'FontName','Times New Roman','FontSize',12,'FontWeight','normal');
set(gcf,'Units','centimeter','Position',[4 4 22 10]);
grid on;
% axis equal

% figure(5)
% plot(out.t, out.disA2Obs(:,1:3),'LineWidth',1.5);hold on;
% plot(out.t, out.disAi2Aj(:,3),'-.','LineWidth',1.5);hold on;
% line([25,75],[5,5],'color','k','linestyle','-.','LineWidth',1);hold on;
% line([25,75],[0.5,0.5],'color','k','linestyle','-','LineWidth',1);hold on;
% 
% hXLabel = xlabel('Time (sec)');
% hYLabel = ylabel('Distance','interpreter','latex');
% set(gca, 'Box', 'on', ...                                        % ��
%         'LineWidth',0.5, ...
%         'XGrid', 'off', 'YGrid', 'off', ...                      % ����
%         'TickDir', 'in', 'TickLength', [.015 .015], ...          % �̶�
%         'XMinorTick', 'on', 'YMinorTick', 'on', ...              % С�̶�
%         'XColor', [.1 .1 .1],  'YColor',[.1 .1 .1],...           % ��������ɫ
%         'XTick', 25:12:70,...                                    % �������̶ȡ���Χ
%         'XLim', [25 70],...
%         'YTick', 0:5:25,...
%         'YLim', [0 25]);
% % �����������������
% set(gca, 'FontName', 'Times New Roman')
% set([hXLabel, hYLabel], 'FontName','Times New Roman')
% set(gca, 'FontSize', 18)
% %����ͼ��
% h=legend('$\left\|{{r}_{1}}-{{o}_{1}}\right\|$','$\left\|{{r}_{2}}-{{o}_{1}}\right\|$','$\left\|{{r}_{3}}-{{o}_{1}}\right\|$','$\left\|{{r}_{1}}-{{r}_{3}}\right\|$','$r_l^o+{d^f}$','$d_{c}^{s}$','NumColumns',2,'interpreter','latex');
% set(h,'FontName','Times New Roman','FontSize',13,'FontWeight','normal');
% set(gcf,'Units','centimeter','Position',[4 4 14 12]);

% figure(6)
% plot(out.t, out1.disA2Obs(:,1),'k--','LineWidth',1.5);hold on;
% %plot(out.t, out1.disA2Obs(:,2),'r--','LineWidth',1.5);hold on;
% plot(out.t, out1.disA2Obs(:,3),'b--','LineWidth',1.5);hold on;
% plot(out.t, out.disA2Obs(:,1),'k','LineWidth',1.5);hold on;
% %plot(out.t, out.disA2Obs(:,2),'r','LineWidth',1.5);hold on;
% plot(out.t, out.disA2Obs(:,3),'b','LineWidth',1.5);hold on;
% line([25,75],[5,5],'color','k','linestyle','-.','LineWidth',1);hold on;
% line([25,75],[2,2],'color','k','linestyle','-','LineWidth',1);hold on;
% 
% hXLabel = xlabel('Time (sec)');
% hYLabel = ylabel('Distance','interpreter','latex');
% set(gca, 'Box', 'on', ...                                        % ��
%         'LineWidth',0.5, ...
%         'XGrid', 'off', 'YGrid', 'off', ...                      % ����
%         'TickDir', 'in', 'TickLength', [.015 .015], ...          % �̶�
%         'XMinorTick', 'on', 'YMinorTick', 'on', ...              % С�̶�
%         'XColor', [.1 .1 .1],  'YColor',[.1 .1 .1],...           % ��������ɫ
%         'XTick', 25:12:70,...                                    % �������̶ȡ���Χ
%         'XLim', [25 70],...
%         'YTick', 0:5:25,...
%         'YLim', [0 25]);
% % �����������������
% set(gca, 'FontName', 'Times New Roman')
% set([hXLabel, hYLabel], 'FontName','Times New Roman')
% set(gca, 'FontSize', 18)
% %����ͼ��
% h=legend('$\left\|{{r}_{1}}-{{o}_{1}}\right\|$ without proposed method','$\left\|{{r}_{3}}-{{o}_{1}}\right\|$ without proposed method','$\left\|{{r}_{1}}-{{o}_{1}}\right\|$ with proposed method','$\left\|{{r}_{3}}-{{o}_{1}}\right\|$ with proposed method','Safe distance','Obstacle radius','NumColumns',1,'interpreter','latex');
% set(h,'FontName','Times New Roman','FontSize',12,'FontWeight','normal');
% set(gcf,'Units','centimeter','Position',[4 4 14 12]);

figure(7)
quiver(out.pos1(1,1:12),out.pos(1,1:12),out.x1(1,1:12),out.x(1,1:12), 3,'r-','linewidth',2, 'MaxHeadSize', 2);hold on;
quiver(out.pos1(1,13:24),out.pos(1,13:24),out.x1(1,13:24),out.x(1,13:24), 3, 'b-','linewidth',2, 'MaxHeadSize', 2);hold on;

plot(out.pos1(1,:),out.pos(1,:),'o','color','k','MarkerSize',8,'LineWidth',1.5); hold on;

title('t=0s,All agents');
% hXLabel = xlabel('$r_i^y(t)$','interpreter','latex');
% hYLabel = ylabel('$r_i^x(t)$','interpreter','latex');
set(gca, 'Box', 'on', ...                                        % ��
        'LineWidth',0.5, ...
        'XGrid', 'off', 'YGrid', 'off', ...                      % ����
        'TickDir', 'in', 'TickLength', [.015 .015], ...          % �̶�
        'XMinorTick', 'on', 'YMinorTick', 'on', ...              % С�̶�
        'XColor', [.1 .1 .1],  'YColor',[.1 .1 .1],...           % ��������ɫ
        'XTick', -12:3:15,...                                    % �������̶ȡ���Χ
        'XLim', [-12 15],...
        'YTick', -5:2:5,...
        'YLim', [-5 5]);
% �����������������
set(gca, 'FontName', 'Times New Roman')
% set([hXLabel, hYLabel], 'FontName','Times New Roman')
set(gca, 'FontSize', 18)
% set([hXLabel, hYLabel], 'FontSize', 18, 'FontWeight' ,'normal')
% set(hTitle, 'FontSize', 18, 'FontWeight' ,'bold')
% ����ͼ��
% h=legend('Agent1','Agent2','Agent3','Agent4','Agent5','Agent6','Agent7',...
%     'Agent8','ITS','IHS','Obs','NumColumns',3,'interpreter','latex');
% set(h,'FontName','Times New Roman','FontSize',12,'FontWeight','normal');
set(gcf,'Units','centimeter','Position',[3 3 16 6]);
axis equal

figure(8)
subplot(2,2,1)
%�ϰ���Ĳ���
centerX = 40; centerY = -1.2; radius = 1.5;

% �����Ƕ�����������x��y����
theta = linspace(0, 2*pi, 100);
x = centerX + radius * cos(theta);
y = centerY + radius * sin(theta);

% �������Բ
fill(x, y, [0.8 0.8 0.8]); hold on;
plot(x, y, 'k-.','linewidth',1.0); hold on;
%quiver(out.pos(520,:),out.pos1(520,:),out.x(520,:),out.x1(520,:),0.2,'b','linewidth',2);hold on;

quiver(out.pos1(230,1:12),out.pos(230,1:12),out.x1(230,1:12),out.x(230,1:12), 0.32,'r-','linewidth',2);hold on;
quiver(out.pos1(230,13:24),out.pos(230,13:24),out.x1(230,13:24),out.x(230,13:24), 0.32,'b-','linewidth',2);hold on;

plot(out.pos1(230,:),out.pos(230,:),'o','color','k','MarkerSize',8,'LineWidth',1.5);
hold on;
title('t=23.0s,Team 1');
hXLabel = xlabel('$r_i^x(t)$','interpreter','latex');
hYLabel = ylabel('$r_i^y(t)$','interpreter','latex');
set(gca, 'Box', 'on', ...                                        % ��
        'LineWidth',0.5, ...
        'XGrid', 'off', 'YGrid', 'off', ...                      % ����
        'TickDir', 'in', 'TickLength', [.015 .015], ...          % �̶�
        'XMinorTick', 'on', 'YMinorTick', 'on', ...              % С�̶�
        'XColor', [.1 .1 .1],  'YColor',[.1 .1 .1]); %,...           % ��������ɫ
%         'XTick', 25:4:37,...                                    % �������̶ȡ���Χ
%         'XLim', [25 37],...
%         'YTick', 5:5:15,...
%         'YLim', [5 15]);
% �����������������
xlim([10 50]);
ylim([-20 20]);
set(gca, 'FontName', 'Times New Roman')
% set([hXLabel, hYLabel], 'FontName','Times New Roman')
set(gca, 'FontSize', 15)
% set([hXLabel, hYLabel], 'FontSize', 18, 'FontWeight' ,'normal')
% set(hTitle, 'FontSize', 18, 'FontWeight' ,'bold')
% ����ͼ��
% h=legend('Agent1','Agent2','Agent3','Agent4','Agent5','Agent6','Agent7',...
%     'Agent8','ITS','IHS','Obs','NumColumns',3,'interpreter','latex');
% set(h,'FontName','Times New Roman','FontSize',12,'FontWeight','normal');
set(gcf,'Units','centimeter','Position',[3 3 16 14]);

subplot(2,2,2)
%�ϰ���Ĳ���
centerX = 35; centerY = 5; radius = 3;

% �����Ƕ�����������x��y����
theta = linspace(0, 2*pi, 100);
x = centerX + radius * cos(theta);
y = centerY + radius * sin(theta);

% �������Բ
fill(x, y, [0.8 0.8 0.8]); hold on;
plot(x, y, 'k-.','linewidth',1.0); hold on;
%quiver(out.pos(800,:),out.pos1(800,:),out.x(800,:),out.x1(800,:),0.15,'b','linewidth',2);hold on;

quiver(out.pos1(500,1:12),out.pos(500,1:12),out.x1(500,1:12),out.x(500,1:12), 0.15,'r-','linewidth',2);hold on;
quiver(out.pos1(500,13:24),out.pos(500,13:24),out.x1(500,13:24),out.x(500,13:24), 0.15,'b-','linewidth',2);hold on;

plot(out.pos1(500,:),out.pos(500,:),'o','color','k','MarkerSize',8,'LineWidth',1.5);
hold on;
title('t=50.0s,Team 1');
hXLabel = xlabel('$r_i^x(t)$','interpreter','latex');
hYLabel = ylabel('$r_i^y(t)$','interpreter','latex');
% set(gca, 'Box', 'on', ...                                        % ��
%         'LineWidth',0.5, ...
%         'XGrid', 'off', 'YGrid', 'off', ...                      % ����
%         'TickDir', 'in', 'TickLength', [.015 .015], ...          % �̶�
%         'XMinorTick', 'on', 'YMinorTick', 'on', ...              % С�̶�
%         'XColor', [.1 .1 .1],  'YColor',[.1 .1 .1]); %,...           % ��������ɫ
%         'XTick', 25:4:37,...                                    % �������̶ȡ���Χ
%         'XLim', [25 37],...
%         'YTick', 5:5:15,...
%         'YLim', [5 15]);
% �����������������
xlim([42 80]);
ylim([-20 20]);
set(gca, 'FontName', 'Times New Roman')
% set([hXLabel, hYLabel], 'FontName','Times New Roman')
set(gca, 'FontSize', 15)
% set([hXLabel, hYLabel], 'FontSize', 18, 'FontWeight' ,'normal')
% set(hTitle, 'FontSize', 18, 'FontWeight' ,'bold')
% ����ͼ��
% h=legend('Agent1','Agent2','Agent3','Agent4','Agent5','Agent6','Agent7',...
%     'Agent8','ITS','IHS','Obs','NumColumns',3,'interpreter','latex');
% set(h,'FontName','Times New Roman','FontSize',12,'FontWeight','normal');
set(gcf,'Units','centimeter','Position',[3 3 16 14]);

subplot(2,2,3)
%�ϰ���Ĳ���
centerX = 35; centerY = 5; radius = 3;

% �����Ƕ�����������x��y����
theta = linspace(0, 2*pi, 100);
x = centerX + radius * cos(theta);
y = centerY + radius * sin(theta);

% �������Բ
fill(x, y, [0.8 0.8 0.8]); hold on;
plot(x, y, 'k-.','linewidth',1.0); hold on;
%quiver(out.pos(434,:),out.pos1(434,:),out.x(434,:),out.x1(434,:),0.2,'r','linewidth',2); hold on;

quiver(out.pos1(220,1:12),out.pos(220,1:12),out.x1(220,1:12),out.x(220,1:12), 0.26,'r-','linewidth',2);hold on;
quiver(out.pos1(220,13:24),out.pos(220,13:24),out.x1(220,13:24),out.x(220,13:24), 0.26,'b-','linewidth',2);hold on;

plot(out.pos1(220,:),out.pos(220,:),'o','color','k','MarkerSize',8,'LineWidth',1.5);
hold on;
title('t=23.0s,Team 2');
hXLabel = xlabel('$r_i^x(t)$','interpreter','latex');
hYLabel = ylabel('$r_i^y(t)$','interpreter','latex');
set(gca, 'Box', 'on', ...                                        % ��
        'LineWidth',0.5, ...
        'XGrid', 'off', 'YGrid', 'off', ...                      % ����
        'TickDir', 'in', 'TickLength', [.015 .015], ...          % �̶�
        'XMinorTick', 'on', 'YMinorTick', 'on', ...              % С�̶�
        'XColor', [.1 .1 .1],  'YColor',[.1 .1 .1]); %,...           % ��������ɫ
%         'XTick', 25:4:37,...                                    % �������̶ȡ���Χ
%         'XLim', [25 37],...
%         'YTick', 5:5:15,...
%         'YLim', [5 15]);
% �����������������
xlim([-40 -5]);
ylim([-16 16]);
set(gca, 'FontName', 'Times New Roman')
% set([hXLabel, hYLabel], 'FontName','Times New Roman')
set(gca, 'FontSize', 15)
% set([hXLabel, hYLabel], 'FontSize', 18, 'FontWeight' ,'normal')
% set(hTitle, 'FontSize', 18, 'FontWeight' ,'bold')
% ����ͼ��
% h=legend('Agent1','Agent2','Agent3','Agent4','Agent5','Agent6','Agent7',...
%     'Agent8','ITS','IHS','Obs','NumColumns',3,'interpreter','latex');
% set(h,'FontName','Times New Roman','FontSize',12,'FontWeight','normal');
set(gcf,'Units','centimeter','Position',[3 3 16 14]);

subplot(2,2,4)
%�ϰ���Ĳ���
centerX = 35; centerY = 5; radius = 3;

% �����Ƕ�����������x��y����
theta = linspace(0, 2*pi, 100);
x = centerX + radius * cos(theta);
y = centerY + radius * sin(theta);

% �������Բ
fill(x, y, [0.8 0.8 0.8]); hold on;
plot(x, y, 'k-.','linewidth',1.0); hold on;
%quiver(out.pos(800,:),out.pos1(800,:),out.x(800,:),out.x1(800,:),0.13,'r','linewidth',2); hold on;

quiver(out.pos1(500,1:12),out.pos(500,1:12),out.x1(500,1:12),out.x(500,1:12), 0.16,'r-','linewidth',2);hold on;
quiver(out.pos1(500,13:24),out.pos(500,13:24),out.x1(500,13:24),out.x(500,13:24), 0.16,'b-','linewidth',2);hold on;

plot(out.pos1(500,:),out.pos(500,:),'o','color','k','MarkerSize',8,'LineWidth',1.5);
hold on;
title('t=50.0s,Team 2');
hXLabel = xlabel('$r_i^x(t)$','interpreter','latex');
hYLabel = ylabel('$r_i^y(t)$','interpreter','latex');
set(gca, 'Box', 'on', ...                                        % ��
        'LineWidth',0.5, ...
        'XGrid', 'off', 'YGrid', 'off', ...                      % ����
        'TickDir', 'in', 'TickLength', [.015 .015], ...          % �̶�
        'XMinorTick', 'on', 'YMinorTick', 'on', ...              % С�̶�
        'XColor', [.1 .1 .1],  'YColor',[.1 .1 .1]); %,...           % ��������ɫ
%         'XTick', 25:4:37,...                                    % �������̶ȡ���Χ
%         'XLim', [25 37],...
%         'YTick', 5:5:15,...
%         'YLim', [5 15]);
% �����������������
xlim([-75 -36]);
ylim([-16 16]);
set(gca, 'FontName', 'Times New Roman')
% set([hXLabel, hYLabel], 'FontName','Times New Roman')
set(gca, 'FontSize', 15)
% set([hXLabel, hYLabel], 'FontSize', 18, 'FontWeight' ,'normal')
% set(hTitle, 'FontSize', 18, 'FontWeight' ,'bold')
% ����ͼ��
% h=legend('Agent1','Agent2','Agent3','Agent4','Agent5','Agent6','Agent7',...
%     'Agent8','ITS','IHS','Obs','NumColumns',3,'interpreter','latex');
% set(h,'FontName','Times New Roman','FontSize',12,'FontWeight','normal');
set(gcf,'Units','centimeter','Position',[3 3 16 14]);

figure(5)
plot(out.t, out.disA2Obs(:,[13,15,20,21]),'LineWidth',1.5);hold on;
%plot(out.t, out.disAi2Aj(:,3),'-.','LineWidth',1.5);hold on;
line([25,75],[1.5,1.5],'color','k','linestyle','-.','LineWidth',1);hold on;
%line([25,75],[0.5,0.5],'color','k','linestyle','-','LineWidth',1);hold on;

hXLabel = xlabel('Time (sec)');
hYLabel = ylabel('Distance','interpreter','latex');
set(gca, 'Box', 'on', ...                                        % ��
        'LineWidth',0.5, ...
        'XGrid', 'off', 'YGrid', 'off', ...                      % ����
        'TickDir', 'in', 'TickLength', [.015 .015], ...          % �̶�
        'XMinorTick', 'on', 'YMinorTick', 'on', ...              % С�̶�
        'XColor', [.1 .1 .1],  'YColor',[.1 .1 .1],...           % ��������ɫ
        'XTick', 25:12:70,...                                    % �������̶ȡ���Χ
        'XLim', [25 70],...
        'YTick', 0:5:25,...
        'YLim', [0 25]);
% �����������������
set(gca, 'FontName', 'Times New Roman')
set([hXLabel, hYLabel], 'FontName','Times New Roman')
set(gca, 'FontSize', 18)
%����ͼ��
h=legend('$\left\|{{r}_{13}}-{{o}_{1}}\right\|$','$\left\|{{r}_{15}}-{{o}_{1}}\right\|$','$\left\|{{r}_{20}}-{{o}_{1}}\right\|$','$\left\|{{r}_{23}}-{{o}_{1}}\right\|$','$\left\|{{r}_{21}}-{{o}_{1}}\right\|$','$r_l^o$','NumColumns',2,'interpreter','latex');
set(h,'FontName','Times New Roman','FontSize',13,'FontWeight','normal');
set(gcf,'Units','centimeter','Position',[4 4 14 12]);

figure(6)
plot(out.t, out1.disA2Obs(:,20),'k--','LineWidth',1.5);hold on;
plot(out.t, out1.disA2Obs(:,21),'r--','LineWidth',1.5);hold on;
%plot(out.t, out1.disA2Obs(:,3),'b--','LineWidth',1.5);hold on;
plot(out.t, out.disA2Obs(:,20),'k','LineWidth',1.5);hold on;
%plot(out.t, out.disA2Obs(:,22),'r','LineWidth',1.5);hold on;
plot(out.t, out.disA2Obs(:,21),'b','LineWidth',1.5);hold on;
line([25,75],[1.5,1.5],'color','k','linestyle','-.','LineWidth',1);hold on;
%line([25,75],[1,1],'color','k','linestyle','-','LineWidth',1);hold on;

hXLabel = xlabel('Time (sec)');
hYLabel = ylabel('Distance','interpreter','latex');
set(gca, 'Box', 'on', ...                                        % ��
        'LineWidth',0.5, ...
        'XGrid', 'off', 'YGrid', 'off', ...                      % ����
        'TickDir', 'in', 'TickLength', [.015 .015], ...          % �̶�
        'XMinorTick', 'on', 'YMinorTick', 'on', ...              % С�̶�
        'XColor', [.1 .1 .1],  'YColor',[.1 .1 .1],...           % ��������ɫ
        'XTick', 25:12:70,...                                    % �������̶ȡ���Χ
        'XLim', [25 70],...
        'YTick', 0:5:25,...
        'YLim', [0 25]);
% �����������������
set(gca, 'FontName', 'Times New Roman')
set([hXLabel, hYLabel], 'FontName','Times New Roman')
set(gca, 'FontSize', 18)
%����ͼ��
h=legend('$\left\|{{r}_{20}}-{{o}_{1}}\right\|$ without proposed method','$\left\|{{r}_{23}}-{{o}_{1}}\right\|$ without proposed method','$\left\|{{r}_{20}}-{{o}_{1}}\right\|$ with proposed method','$\left\|{{r}_{23}}-{{o}_{1}}\right\|$ with proposed method','Obstacle radius','NumColumns',1,'interpreter','latex');
set(h,'FontName','Times New Roman','FontSize',12,'FontWeight','normal');
set(gcf,'Units','centimeter','Position',[4 4 14 12]);

figure(9)
plot(out.t, out.disAi2Aj(:,10:24),'-','LineWidth',1.5);hold on;
% plot(out.t, out.disAi2Aj(:,3),'w-','LineWidth',0.01);hold on;
% plot(out.t, out.disAi2Aj(:,9),'w-','LineWidth',0.01);hold on;
line([0,120],[0.5,0.5],'color','k','linestyle','-.','LineWidth',0.5);hold on;

hXLabel = xlabel('Time (sec)');
hYLabel = ylabel('Distance','interpreter','latex');
set(gca, 'Box', 'on', ...                                        % ��
        'LineWidth',0.5, ...
        'XGrid', 'off', 'YGrid', 'off', ...                      % ����
        'TickDir', 'in', 'TickLength', [.015 .015], ...          % �̶�
        'XMinorTick', 'on', 'YMinorTick', 'on', ...              % С�̶�
        'XColor', [.1 .1 .1],  'YColor',[.1 .1 .1],...           % ��������ɫ
        'XTick', 0:20:120,...                                    % �������̶ȡ���Χ
        'XLim', [0 120],...
        'YTick', 0:50:350,...
        'YLim', [0 350]);
% �����������������
set(gca, 'FontName', 'Times New Roman')
set([hXLabel, hYLabel], 'FontName','Times New Roman')
set(gca, 'FontSize', 18)
%����ͼ��
% h=legend('$\left\|{{r}_{1}}-{{o}_{1}}\right\|$','$\left\|{{r}_{2}}-{{o}_{1}}\right\|$','$\left\|{{r}_{3}}-{{o}_{1}}\right\|$','$\left\|{{r}_{1}}-{{r}_{3}}\right\|$','$r_l^o$','$d_{c}^{s}$','NumColumns',2,'interpreter','latex');
% set(h,'FontName','Times New Roman','FontSize',13,'FontWeight','normal');
set(gcf,'Units','centimeter','Position',[4 4 14 12]);

% figure(5)
% % plot(state_output.time, state_output.signals.values(:,1),'sk-.','LineWidth',2,'MarkerSize',6,'MarkerIndices',maker_idx);
% plot(out.t, out.flag,'color','k','LineWidth',1);
% 
% hold on;
% % set(gcf,'Units','centimeter','Position',[5 5 18 14]);
% 
% hXLabel = xlabel('Time (sec)');
% hYLabel = ylabel('Triggering instants','interpreter','latex');
% set(gca, 'Box', 'on', ...                                        % ��
%         'LineWidth',0.5, ...
%         'XGrid', 'off', 'YGrid', 'off', ...                      % ����
%         'TickDir', 'in', 'TickLength', [.015 .015], ...          % �̶�
%         'XMinorTick', 'on', 'YMinorTick', 'on', ...              % С�̶�
%         'XColor', [.1 .1 .1],  'YColor',[.1 .1 .1],...           % ��������ɫ
%         'XTick', 0:8:40,...                                    % �������̶ȡ���Χ
%         'XLim', [0 40],...
%         'YTick', -0.1:1.1:1.1,...
%         'YLim', [-0.1 1.1]);
% % �����������������
% set(gca, 'FontName', 'Times New Roman')
% set([hXLabel, hYLabel], 'FontName','Times New Roman')
% set(gca, 'FontSize', 18)
% set([hXLabel, hYLabel], 'FontSize', 18, 'FontWeight' ,'normal')
% % set(hTitle, 'FontSize', 18, 'FontWeight' ,'bold')
% % ����ͼ��
% % h=legend('$v_1(t)$','$v_2(t)$','$v_3(t)$','$v_4(t)$','$v_5(t)$','$v_6(t)$','$v_7(t)$',...
% %     '$v_8(t)$','NumColumns',2,'interpreter','latex');
% % set(h,'FontName','Times New Roman','FontSize',13,'FontWeight','normal');
% set(gcf,'Units','centimeter','Position',[4 4 22 10]);
% grid on;
% 
% 
% figure(6)
% % plot(state_output.time, state_output.signals.values(:,1),'sk-.','LineWidth',2,'MarkerSize',6,'MarkerIndices',maker_idx);
% plot(out.t, out.e_t,'LineWidth',2);
% hold on
% plot(out.t, out.e_tp,'LineWidth',2);
% hold on
% 
% hold on;
% % set(gcf,'Units','centimeter','Position',[5 5 18 14]);
% 
% hXLabel = xlabel('Time (sec)');
% hYLabel = ylabel('Error and boundary threshold','interpreter','latex');
% set(gca, 'Box', 'on', ...                                        % ��
%         'LineWidth',0.5, ...
%         'XGrid', 'off', 'YGrid', 'off', ...                      % ����
%         'TickDir', 'in', 'TickLength', [.015 .015], ...          % �̶�
%         'XMinorTick', 'on', 'YMinorTick', 'on', ...              % С�̶�
%         'XColor', [.1 .1 .1],  'YColor',[.1 .1 .1],...           % ��������ɫ
%         'XTick', 0:1:4,...                                    % �������̶ȡ���Χ
%         'XLim', [0 4],...
%         'YTick', -0.2:0.2:2,...
%         'YLim', [-0.2 2]);
% % �����������������
% set(gca, 'FontName', 'Times New Roman')
% set([hXLabel, hYLabel], 'FontName','Times New Roman')
% set(gca, 'FontSize', 18)
% set([hXLabel, hYLabel], 'FontSize', 18, 'FontWeight' ,'normal')
% % set(hTitle, 'FontSize', 18, 'FontWeight' ,'bold')
% % ����ͼ��
% h=legend('Error','$Boundary$','NumColumns',2,'interpreter','latex');
% set(h,'FontName','Times New Roman','FontSize',13,'FontWeight','normal');
% set(gcf,'Units','centimeter','Position',[4 4 18 12]);
% grid on;

% 
% figure(4)
% % plot(state_output.time, state_output.signals.values(:,1),'sk-.','LineWidth',2,'MarkerSize',6,'MarkerIndices',maker_idx);
% plot(out.t, out.y1,'LineWidth',2);
% 
% hold on;
% % set(gcf,'Units','centimeter','Position',[5 5 18 14]);
% 
% hXLabel = xlabel('Time (sec)');
% hYLabel = ylabel('The sampling state $x_i(t_k)$','interpreter','latex');
% set(gca, 'Box', 'on', ...                                        % ��
%         'LineWidth',0.5, ...
%         'XGrid', 'off', 'YGrid', 'off', ...                      % ����
%         'TickDir', 'in', 'TickLength', [.015 .015], ...          % �̶�
%         'XMinorTick', 'on', 'YMinorTick', 'on', ...              % С�̶�
%         'XColor', [.1 .1 .1],  'YColor',[.1 .1 .1],...           % ��������ɫ
%         'XTick', 0:1:4,...                                    % �������̶ȡ���Χ
%         'XLim', [0 4],...
%         'YTick', -3:2:9,...
%         'YLim', [-3 9]);
% % �����������������
% set(gca, 'FontName', 'Times New Roman')
% set([hXLabel, hYLabel], 'FontName','Times New Roman')
% set(gca, 'FontSize', 18)
% set([hXLabel, hYLabel], 'FontSize', 18, 'FontWeight' ,'normal')
% % set(hTitle, 'FontSize', 18, 'FontWeight' ,'bold')
% % ����ͼ��
% h=legend('$x_1(t_k)$','$x_2(t_k)$','$x_3(t_k)$','$x_4(t_k)$','$x_5(t_k)$','$x_6(t_k)$','$x_7(t_k)$',...
%     '$x_8(t_k)$','NumColumns',2,'interpreter','latex');
% set(h,'FontName','Times New Roman','FontSize',13,'FontWeight','normal');
% set(gcf,'Units','centimeter','Position',[4 4 22 10]);
% grid on;
