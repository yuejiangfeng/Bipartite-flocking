function [sys,x0,str,ts] = trigf(t,x,u,flag)
switch flag
case 0
    [sys,x0,str,ts]=mdlInitializeSizes;
case 3
    sys=mdlOutputs(t,x,u);
case {2,4,9}
    sys=[];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end

function [sys,x0,str,ts] = mdlInitializeSizes
sizes = simsizes;
sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 3;
sizes.NumInputs      = 8 + 8;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 0;
sys = simsizes(sizes);
x0  = [];
str = [];
ts  = [];
function sys=mdlOutputs(t,x,u)

% A = [
%     0 1 0 0 0 1 0 0
%     1 0 1 0 0 0 1 0
%     0 1 0 1 0 0 0 1
%     0 0 1 0 1 0 0 0
%     0 0 0 1 0 1 0 0
%     1 0 0 0 1 0 1 0
%     0 1 0 0 0 1 0 0
%     0 0 1 0 1 0 0 0    
%     ];
A = [
    0 1 0 0 0 1 0 0
    1 0 -1 0 0 0 1 0
    0 -1 0 1 0 0 0 1
    0 0 1 0 1 0 0 0
    0 0 0 1 0 -1 0 0
    1 0 0 0 -1 0 1 0
    0 1 0 0 0 1 0 0
    0 0 1 0 1 0 0 0    
    ];
n = length(A);
L = diag(sum(A,2)) - A;
x = u(1:8);
x_hat = u(9:16);
e_t = x - x_hat;

c = sum(x)/8;
In = ones(8,1);
e_r = norm(x-c*In)/norm(L);
e_l = norm(e_t);

if t < 1.5
    k1 = (1.5-t)/(5-t);
else
    k1 = 0;
end

eta = e_l - (1+k1)*e_r;

if eta >=0
    sys(1)=1;
else
    sys(1)=0;
end

sys(2)=norm(e_l);
sys(3)=norm((1+k1)*e_r);