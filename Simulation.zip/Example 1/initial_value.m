%%%%% Jiangfeng Yue %%%%% 
%%%%%    2025.08    %%%%% 
% Title "Secure Flocking Dynamics of Swarms Over Cooperative-Antagonistic Networks"

clc
clear

% initial states
intial_x1 = ((rand (1,8)*3)-0);    % X-direction
intial_x2 = ((rand (1,8)*3)-0);    % Y-direction

intial_v1 = ((rand (1,8)*3)+1);    % X-direction
intial_v2 = ((rand (1,8)*3)+1);    % Y-direction

% This example is a two-robot flocking control algorithm in free space, 
% which integrates time-varying transformation, event-triggered mechanism and predefined time theory.
