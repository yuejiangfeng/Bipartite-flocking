%%%%% Jiangfeng Yue %%%%% 
%%%%%    2025.08    %%%%% 
% Title "Secure Flocking Dynamics of Swarms Over Cooperative-Antagonistic Networks"

clc
clear

% initial states
% intial_x1 = ((rand (1,8)*3)-2);    % X-direction
% intial_x2 = ((rand (1,8)*3)-2);    % Y-direction

intial_x1 = [-0.208,-1.100,-1.597,-1.362,0.684,-1.785,-1.272,-1.838]; % X-direction
intial_x2 = [-0.674,-1.960,0.691,-1.410,-1.719,-1.077,-0.631,-1.694]; % Y-direction

intial_v1 = [2.655,1.307,-0.257,0.134,0.823,1.791,-0.332,-1.329];
intial_v2 = [1.391,1.451,0.869,1.183,0.523,1.862,-0.361,1.455];

% This example is a two-part swarm control algorithm within an obstacle space. 
% It supplements the local motion adjustment function to achieve local obstacle avoidance, 
% and simultaneously integrates time-varying transformation, event-triggered mechanism and predefined time theory.