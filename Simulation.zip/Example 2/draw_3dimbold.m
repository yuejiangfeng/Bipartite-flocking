%maker_idx = 1:70:length(ScopeData6.signals(1).values);

figure(1)
X_true1 = out.pos1(1:1201,:);
Y_true1 = out.pos(1:1201,:);
len = length(X_true1(:,1));
sample = 40;
plot(Y_true1(:,1),X_true1(:,1),'color','#008080','linewidth',2);
hold on
plot(Y_true1(:,2),X_true1(:,2),'LineStyle','-','color','#0072BD','LineWidth',2);
hold on
plot(Y_true1(:,3),X_true1(:,3),'LineStyle','-','color','#D95319','LineWidth',2);
hold on
plot(Y_true1(:,4),X_true1(:,4),'LineStyle','-','color','#EDB120','LineWidth',2);
hold on
plot(Y_true1(:,5),X_true1(:,5),'LineStyle','-','color','#7E2F8E','LineWidth',2);
hold on
plot(Y_true1(:,6),X_true1(:,6),'LineStyle','-','color','#77AC30','LineWidth',2);
hold on
plot(Y_true1(:,7),X_true1(:,7),'LineStyle','-','color','#4DBEEE','LineWidth',2);
hold on
plot(Y_true1(:,8),X_true1(:,8),'LineStyle','-','color','#A2142F','LineWidth',2);
hold on

% for i = 1:8
% plot(Y_true1(:,i),X_true1(:,i),'LineStyle','-','LineWidth',2);
% hold on;
% end
plot(Y_true1(1,1:8),X_true1(1,1:8),'o','color','k','MarkerSize',6,'LineWidth',1.5);
hold on;
% plot(y1(1,:),y2(1,:),'o','color','m','MarkerSize',6,'LineWidth',1);
% hold on;
plot(Y_true1(1201,1:8),X_true1(1201,1:8),'p','color','k','MarkerSize',8,'LineWidth',1.5);
hold on;
grid on;

%�ϰ���Ĳ���
centerX = 40; centerY = -3; radius = 2;

% �����Ƕ�����������x��y����
theta = linspace(0, 2*pi, 100);
x = centerX + radius * cos(theta);
y = centerY + radius * sin(theta);

% �������Բ
fill(x, y, [0.8 0.8 0.8]); hold on;
plot(x, y, 'k-.','linewidth',1.0); hold on;

% set(gcf,'Units','centimeter','Position',[5 5 18 14]);

hXLabel = xlabel('$r_i^y(t)$','interpreter','latex');
hYLabel = ylabel('$r_i^x(t)$','interpreter','latex');
set(gca, 'Box', 'on', ...                                        % ��
        'LineWidth',0.5, ...
        'XGrid', 'off', 'YGrid', 'off', ...                      % ����
        'TickDir', 'in', 'TickLength', [.015 .015], ...          % �̶�
        'XMinorTick', 'on', 'YMinorTick', 'on', ...              % С�̶�
        'XColor', [.1 .1 .1],  'YColor',[.1 .1 .1]);  %,...           % ��������ɫ
        %'XTick', -40:10:50,...                                    % �������̶ȡ���Χ
        %'XLim', [-40 50],...
        %'YTick', -8:4:12,...
        %'YLim', [-8 12]);
% �����������������
set(gca, 'FontName', 'Times New Roman')
set([hXLabel, hYLabel], 'FontName','Times New Roman')
set(gca, 'FontSize', 18)
set([hXLabel, hYLabel], 'FontSize', 18, 'FontWeight' ,'normal')
% set(hTitle, 'FontSize', 18, 'FontWeight' ,'bold')
% ����ͼ��
h=legend('Agent1','Agent2','Agent3','Agent4','Agent5','Agent6','Agent7',...
    'Agent8','ITS','IHS','Obs','NumColumns',3,'interpreter','latex');
set(h,'FontName','Times New Roman','FontSize',12,'FontWeight','normal');
set(gcf,'Units','centimeter','Position',[4 4 22 10]);
grid on;

figure(2)
plot(out.t, out.x(:,1:3),'LineWidth',2);hold on;
plot(out.t, out.x(:,4:8),'LineWidth',2);hold on;
hold on;

hXLabel = xlabel('Time (sec)');
hYLabel = ylabel('True states $v_i(t)$','interpreter','latex');
set(gca, 'Box', 'on', ...                                        % ��
        'LineWidth',0.5, ...
        'XGrid', 'off', 'YGrid', 'off', ...                      % ����
        'TickDir', 'in', 'TickLength', [.015 .015], ...          % �̶�
        'XMinorTick', 'on', 'YMinorTick', 'on', ...              % С�̶�
        'XColor', [.1 .1 .1],  'YColor',[.1 .1 .1],...           % ��������ɫ
        'XTick', 35:5:60,...                                    % �������̶ȡ���Χ
        'XLim', [35 60],...
        'YTick', -2:2:4,...
        'YLim', [-2 4]);
% �����������������
set(gca, 'FontName', 'Times New Roman')
set([hXLabel, hYLabel], 'FontName','Times New Roman')
set(gca, 'FontSize', 18)
set([hXLabel, hYLabel], 'FontSize', 18, 'FontWeight' ,'normal')
% set(hTitle, 'FontSize', 18, 'FontWeight' ,'bold')
% ����ͼ��
h=legend('$v_1(t)$','$v_2(t)$','$v_3(t)$','$v_4(t)$','$v_5(t)$','$v_6(t)$','$v_7(t)$',...
    '$v_8(t)$','NumColumns',2,'interpreter','latex');
set(h,'FontName','Times New Roman','FontSize',13,'FontWeight','normal');
set(gcf,'Units','centimeter','Position',[4 4 14 12]);
%set(gcf,'Units','centimeter','Position',[4 4 22 10]);
grid on;

figure(3)
plot(out.t, out.disA2Obs(:,1:3),'LineWidth',1.5);hold on;
plot(out.t, out.disAi2Aj(:,3),'-.','LineWidth',1.5);hold on;
line([25,75],[5,5],'color','k','linestyle','-.','LineWidth',1);hold on;
line([25,75],[0.5,0.5],'color','k','linestyle','-','LineWidth',1);hold on;

hXLabel = xlabel('Time (sec)');
hYLabel = ylabel('Distance','interpreter','latex');
set(gca, 'Box', 'on', ...                                        % ��
        'LineWidth',0.5, ...
        'XGrid', 'off', 'YGrid', 'off', ...                      % ����
        'TickDir', 'in', 'TickLength', [.015 .015], ...          % �̶�
        'XMinorTick', 'on', 'YMinorTick', 'on', ...              % С�̶�
        'XColor', [.1 .1 .1],  'YColor',[.1 .1 .1],...           % ��������ɫ
        'XTick', 25:12:70,...                                    % �������̶ȡ���Χ
        'XLim', [25 70],...
        'YTick', 0:5:25,...
        'YLim', [0 25]);
% �����������������
set(gca, 'FontName', 'Times New Roman')
set([hXLabel, hYLabel], 'FontName','Times New Roman')
set(gca, 'FontSize', 18)
%����ͼ��
h=legend('$\left\|{{r}_{1}}-{{o}_{1}}\right\|$','$\left\|{{r}_{2}}-{{o}_{1}}\right\|$','$\left\|{{r}_{3}}-{{o}_{1}}\right\|$','$\left\|{{r}_{1}}-{{r}_{3}}\right\|$','$r_l^o+{d^f}$','$d_{c}^{s}$','NumColumns',2,'interpreter','latex');
set(h,'FontName','Times New Roman','FontSize',13,'FontWeight','normal');
set(gcf,'Units','centimeter','Position',[4 4 14 12]);

figure(4)
% plot(out.t, out1.disA2Obs(:,1),'k--','LineWidth',1.5);hold on;
% plot(out.t, out1.disA2Obs(:,2),'r--','LineWidth',1.5);hold on;
% plot(out.t, out1.disA2Obs(:,3),'b--','LineWidth',1.5);hold on;
plot(out.t, out.disA2Obs(:,1),'k','LineWidth',1.5);hold on;
plot(out.t, out.disA2Obs(:,2),'r','LineWidth',1.5);hold on;
plot(out.t, out.disA2Obs(:,3),'b','LineWidth',1.5);hold on;
line([25,75],[5,5],'color','k','linestyle','-.','LineWidth',1);hold on;
line([25,75],[2,2],'color','k','linestyle','-','LineWidth',1);hold on;

hXLabel = xlabel('Time (sec)');
hYLabel = ylabel('Distance','interpreter','latex');
set(gca, 'Box', 'on', ...                                        % ��
        'LineWidth',0.5, ...
        'XGrid', 'off', 'YGrid', 'off', ...                      % ����
        'TickDir', 'in', 'TickLength', [.015 .015], ...          % �̶�
        'XMinorTick', 'on', 'YMinorTick', 'on', ...              % С�̶�
        'XColor', [.1 .1 .1],  'YColor',[.1 .1 .1],...           % ��������ɫ
        'XTick', 25:12:70,...                                    % �������̶ȡ���Χ
        'XLim', [25 70],...
        'YTick', 0:5:25,...
        'YLim', [0 25]);
% �����������������
set(gca, 'FontName', 'Times New Roman')
set([hXLabel, hYLabel], 'FontName','Times New Roman')
set(gca, 'FontSize', 18)
%����ͼ��
h=legend('$\left\|{{r}_{1}}-{{o}_{1}}\right\|$ without proposed method','$\left\|{{r}_{3}}-{{o}_{1}}\right\|$ without proposed method','$\left\|{{r}_{1}}-{{o}_{1}}\right\|$ with proposed method','$\left\|{{r}_{3}}-{{o}_{1}}\right\|$ with proposed method','Safe distance','Obstacle radius','NumColumns',1,'interpreter','latex');
set(h,'FontName','Times New Roman','FontSize',12,'FontWeight','normal');
set(gcf,'Units','centimeter','Position',[4 4 14 12]);

% figure(7)
% quiver(out.pos(1,:),out.pos1(1,:),out.x(1,:),out.x1(1,:) ,'k','linewidth',2);
% hold on;
% plot(out.pos(1,:),out.pos1(1,:),'o','color','k','MarkerSize',8,'LineWidth',1.5);
% hold on;
% title('t=0s,All agents');
% % hXLabel = xlabel('$r_i^y(t)$','interpreter','latex');
% % hYLabel = ylabel('$r_i^x(t)$','interpreter','latex');
% set(gca, 'Box', 'on', ...                                        % ��
%         'LineWidth',0.5, ...
%         'XGrid', 'off', 'YGrid', 'off', ...                      % ����
%         'TickDir', 'in', 'TickLength', [.015 .015], ...          % �̶�
%         'XMinorTick', 'on', 'YMinorTick', 'on', ...              % С�̶�
%         'XColor', [.1 .1 .1],  'YColor',[.1 .1 .1],...           % ��������ɫ
%         'XTick', -1:2:7,...                                    % �������̶ȡ���Χ
%         'XLim', [-1 7],...
%         'YTick', -6:3:7,...
%         'YLim', [-6 7]);
% % �����������������
% set(gca, 'FontName', 'Times New Roman')
% % set([hXLabel, hYLabel], 'FontName','Times New Roman')
% set(gca, 'FontSize', 18)
% % set([hXLabel, hYLabel], 'FontSize', 18, 'FontWeight' ,'normal')
% % set(hTitle, 'FontSize', 18, 'FontWeight' ,'bold')
% % ����ͼ��
% % h=legend('Agent1','Agent2','Agent3','Agent4','Agent5','Agent6','Agent7',...
% %     'Agent8','ITS','IHS','Obs','NumColumns',3,'interpreter','latex');
% % set(h,'FontName','Times New Roman','FontSize',12,'FontWeight','normal');
% set(gcf,'Units','centimeter','Position',[3 3 8 14]);
% axis equal

% figure(8)
% subplot(2,2,1)
% %�ϰ���Ĳ���
% centerX = 35; centerY = 5; radius = 3;
% 
% % �����Ƕ�����������x��y����
% theta = linspace(0, 2*pi, 100);
% x = centerX + radius * cos(theta);
% y = centerY + radius * sin(theta);
% 
% % �������Բ
% fill(x, y, [0.8 0.8 0.8]); hold on;
% plot(x, y, 'k-.','linewidth',1.0); hold on;
% quiver(out.pos(434,:),out.pos1(434,:),out.x(434,:),out.x1(434,:),0.2,'b','linewidth',2);
% hold on;
% plot(out.pos(434,:),out.pos1(434,:),'o','color','k','MarkerSize',8,'LineWidth',1.5);
% hold on;
% title('t=4.34s,Subgroup 1');
% hXLabel = xlabel('$r_i^y(t)$','interpreter','latex');
% hYLabel = ylabel('$r_i^x(t)$','interpreter','latex');
% set(gca, 'Box', 'on', ...                                        % ��
%         'LineWidth',0.5, ...
%         'XGrid', 'off', 'YGrid', 'off', ...                      % ����
%         'TickDir', 'in', 'TickLength', [.015 .015], ...          % �̶�
%         'XMinorTick', 'on', 'YMinorTick', 'on', ...              % С�̶�
%         'XColor', [.1 .1 .1],  'YColor',[.1 .1 .1]); %,...           % ��������ɫ
%         'XTick', 25:4:37,...                                    % �������̶ȡ���Χ
%         'XLim', [25 37],...
%         'YTick', 5:5:15,...
%         'YLim', [5 15]);
% % �����������������
% xlim([25 37]);
% ylim([4 16]);
% set(gca, 'FontName', 'Times New Roman')
% % set([hXLabel, hYLabel], 'FontName','Times New Roman')
% set(gca, 'FontSize', 15)
% % set([hXLabel, hYLabel], 'FontSize', 18, 'FontWeight' ,'normal')
% % set(hTitle, 'FontSize', 18, 'FontWeight' ,'bold')
% % ����ͼ��
% % h=legend('Agent1','Agent2','Agent3','Agent4','Agent5','Agent6','Agent7',...
% %     'Agent8','ITS','IHS','Obs','NumColumns',3,'interpreter','latex');
% % set(h,'FontName','Times New Roman','FontSize',12,'FontWeight','normal');
% set(gcf,'Units','centimeter','Position',[3 3 14 14]);
% 
% subplot(2,2,2)
% %�ϰ���Ĳ���
% centerX = 35; centerY = 5; radius = 3;
% 
% % �����Ƕ�����������x��y����
% theta = linspace(0, 2*pi, 100);
% x = centerX + radius * cos(theta);
% y = centerY + radius * sin(theta);
% 
% % �������Բ
% fill(x, y, [0.8 0.8 0.8]); hold on;
% plot(x, y, 'k-.','linewidth',1.0); hold on;
% quiver(out.pos(800,:),out.pos1(800,:),out.x(800,:),out.x1(800,:),0.2,'b','linewidth',2);
% hold on;
% plot(out.pos(800,:),out.pos1(800,:),'o','color','k','MarkerSize',8,'LineWidth',1.5);
% hold on;
% title('t=8.00s,Subgroup 1');
% % hXLabel = xlabel('$r_i^y(t)$','interpreter','latex');
% % hYLabel = ylabel('$r_i^x(t)$','interpreter','latex');
% % set(gca, 'Box', 'on', ...                                        % ��
% %         'LineWidth',0.5, ...
% %         'XGrid', 'off', 'YGrid', 'off', ...                      % ����
% %         'TickDir', 'in', 'TickLength', [.015 .015], ...          % �̶�
% %         'XMinorTick', 'on', 'YMinorTick', 'on', ...              % С�̶�
% %         'XColor', [.1 .1 .1],  'YColor',[.1 .1 .1]); %,...           % ��������ɫ
% %         'XTick', 25:4:37,...                                    % �������̶ȡ���Χ
% %         'XLim', [25 37],...
% %         'YTick', 5:5:15,...
% %         'YLim', [5 15]);
% % �����������������
% xlim([45 65]);
% ylim([8 28]);
% set(gca, 'FontName', 'Times New Roman')
% % set([hXLabel, hYLabel], 'FontName','Times New Roman')
% set(gca, 'FontSize', 15)
% % set([hXLabel, hYLabel], 'FontSize', 18, 'FontWeight' ,'normal')
% % set(hTitle, 'FontSize', 18, 'FontWeight' ,'bold')
% % ����ͼ��
% % h=legend('Agent1','Agent2','Agent3','Agent4','Agent5','Agent6','Agent7',...
% %     'Agent8','ITS','IHS','Obs','NumColumns',3,'interpreter','latex');
% % set(h,'FontName','Times New Roman','FontSize',12,'FontWeight','normal');
% set(gcf,'Units','centimeter','Position',[3 3 14 14]);
% 
% subplot(2,2,3)
% %�ϰ���Ĳ���
% centerX = 35; centerY = 5; radius = 3;
% 
% % �����Ƕ�����������x��y����
% theta = linspace(0, 2*pi, 100);
% x = centerX + radius * cos(theta);
% y = centerY + radius * sin(theta);
% 
% % �������Բ
% fill(x, y, [0.8 0.8 0.8]); hold on;
% plot(x, y, 'k-.','linewidth',1.0); hold on;
% quiver(out.pos(434,:),out.pos1(434,:),out.x(434,:),out.x1(434,:),0.2,'r','linewidth',2);
% hold on;
% plot(out.pos(434,:),out.pos1(434,:),'o','color','k','MarkerSize',8,'LineWidth',1.5);
% hold on;
% title('t=4.34s,Subgroup 2');
% hXLabel = xlabel('$r_i^y(t)$','interpreter','latex');
% hYLabel = ylabel('$r_i^x(t)$','interpreter','latex');
% set(gca, 'Box', 'on', ...                                        % ��
%         'LineWidth',0.5, ...
%         'XGrid', 'off', 'YGrid', 'off', ...                      % ����
%         'TickDir', 'in', 'TickLength', [.015 .015], ...          % �̶�
%         'XMinorTick', 'on', 'YMinorTick', 'on', ...              % С�̶�
%         'XColor', [.1 .1 .1],  'YColor',[.1 .1 .1]); %,...           % ��������ɫ
%         'XTick', 25:4:37,...                                    % �������̶ȡ���Χ
%         'XLim', [25 37],...
%         'YTick', 5:5:15,...
%         'YLim', [5 15]);
% �����������������
% xlim([-34 -20]);
% ylim([-15 -1]);
% set(gca, 'FontName', 'Times New Roman')
% % set([hXLabel, hYLabel], 'FontName','Times New Roman')
% set(gca, 'FontSize', 15)
% % set([hXLabel, hYLabel], 'FontSize', 18, 'FontWeight' ,'normal')
% % set(hTitle, 'FontSize', 18, 'FontWeight' ,'bold')
% % ����ͼ��
% % h=legend('Agent1','Agent2','Agent3','Agent4','Agent5','Agent6','Agent7',...
% %     'Agent8','ITS','IHS','Obs','NumColumns',3,'interpreter','latex');
% % set(h,'FontName','Times New Roman','FontSize',12,'FontWeight','normal');
% set(gcf,'Units','centimeter','Position',[3 3 14 14]);
% 
% subplot(2,2,4)
% %�ϰ���Ĳ���
% centerX = 35; centerY = 5; radius = 3;
% 
% % �����Ƕ�����������x��y����
% theta = linspace(0, 2*pi, 100);
% x = centerX + radius * cos(theta);
% y = centerY + radius * sin(theta);
% 
% % �������Բ
% fill(x, y, [0.8 0.8 0.8]); hold on;
% plot(x, y, 'k-.','linewidth',1.0); hold on;
% quiver(out.pos(800,:),out.pos1(800,:),out.x(800,:),out.x1(800,:),0.2,'r','linewidth',2);
% hold on;
% plot(out.pos(800,:),out.pos1(800,:),'o','color','k','MarkerSize',8,'LineWidth',1.5);
% hold on;
% title('t=8.00s,Subgroup 2');
% hXLabel = xlabel('$r_i^y(t)$','interpreter','latex');
% hYLabel = ylabel('$r_i^x(t)$','interpreter','latex');
% set(gca, 'Box', 'on', ...                                        % ��
%         'LineWidth',0.5, ...
%         'XGrid', 'off', 'YGrid', 'off', ...                      % ����
%         'TickDir', 'in', 'TickLength', [.015 .015], ...          % �̶�
%         'XMinorTick', 'on', 'YMinorTick', 'on', ...              % С�̶�
%         'XColor', [.1 .1 .1],  'YColor',[.1 .1 .1]); %,...           % ��������ɫ
%         'XTick', 25:4:37,...                                    % �������̶ȡ���Χ
%         'XLim', [25 37],...
%         'YTick', 5:5:15,...
%         'YLim', [5 15]);
% �����������������
% xlim([-65 -35]);
% ylim([-30 0]);
% set(gca, 'FontName', 'Times New Roman')
% % set([hXLabel, hYLabel], 'FontName','Times New Roman')
% set(gca, 'FontSize', 15)
% % set([hXLabel, hYLabel], 'FontSize', 18, 'FontWeight' ,'normal')
% % set(hTitle, 'FontSize', 18, 'FontWeight' ,'bold')
% % ����ͼ��
% % h=legend('Agent1','Agent2','Agent3','Agent4','Agent5','Agent6','Agent7',...
% %     'Agent8','ITS','IHS','Obs','NumColumns',3,'interpreter','latex');
% % set(h,'FontName','Times New Roman','FontSize',12,'FontWeight','normal');
% set(gcf,'Units','centimeter','Position',[3 3 14 14]);
% figure(5)
% % plot(state_output.time, state_output.signals.values(:,1),'sk-.','LineWidth',2,'MarkerSize',6,'MarkerIndices',maker_idx);
% plot(out.t, out.flag,'color','k','LineWidth',1);
% 
% hold on;
% % set(gcf,'Units','centimeter','Position',[5 5 18 14]);
% 
% hXLabel = xlabel('Time (sec)');
% hYLabel = ylabel('Triggering instants','interpreter','latex');
% set(gca, 'Box', 'on', ...                                        % ��
%         'LineWidth',0.5, ...
%         'XGrid', 'off', 'YGrid', 'off', ...                      % ����
%         'TickDir', 'in', 'TickLength', [.015 .015], ...          % �̶�
%         'XMinorTick', 'on', 'YMinorTick', 'on', ...              % С�̶�
%         'XColor', [.1 .1 .1],  'YColor',[.1 .1 .1],...           % ��������ɫ
%         'XTick', 0:8:40,...                                    % �������̶ȡ���Χ
%         'XLim', [0 40],...
%         'YTick', -0.1:1.1:1.1,...
%         'YLim', [-0.1 1.1]);
% % �����������������
% set(gca, 'FontName', 'Times New Roman')
% set([hXLabel, hYLabel], 'FontName','Times New Roman')
% set(gca, 'FontSize', 18)
% set([hXLabel, hYLabel], 'FontSize', 18, 'FontWeight' ,'normal')
% % set(hTitle, 'FontSize', 18, 'FontWeight' ,'bold')
% % ����ͼ��
% % h=legend('$v_1(t)$','$v_2(t)$','$v_3(t)$','$v_4(t)$','$v_5(t)$','$v_6(t)$','$v_7(t)$',...
% %     '$v_8(t)$','NumColumns',2,'interpreter','latex');
% % set(h,'FontName','Times New Roman','FontSize',13,'FontWeight','normal');
% set(gcf,'Units','centimeter','Position',[4 4 22 10]);
% grid on;
% figure(3)
% % plot(state_output.time, state_output.signals.values(:,1),'sk-.','LineWidth',2,'MarkerSize',6,'MarkerIndices',maker_idx);
% plot(out.t, out.e_t,'LineWidth',2);
% hold on
% plot(out.t, out.e_tp,'LineWidth',2);
% hold on
% 
% hold on;
% % set(gcf,'Units','centimeter','Position',[5 5 18 14]);
% 
% hXLabel = xlabel('Time (sec)');
% hYLabel = ylabel('Error and boundary threshold','interpreter','latex');
% set(gca, 'Box', 'on', ...                                        % ��
%         'LineWidth',0.5, ...
%         'XGrid', 'off', 'YGrid', 'off', ...                      % ����
%         'TickDir', 'in', 'TickLength', [.015 .015], ...          % �̶�
%         'XMinorTick', 'on', 'YMinorTick', 'on', ...              % С�̶�
%         'XColor', [.1 .1 .1],  'YColor',[.1 .1 .1],...           % ��������ɫ
%         'XTick', 0:1:4,...                                    % �������̶ȡ���Χ
%         'XLim', [0 4],...
%         'YTick', -0.2:0.2:2,...
%         'YLim', [-0.2 2]);
% % �����������������
% set(gca, 'FontName', 'Times New Roman')
% set([hXLabel, hYLabel], 'FontName','Times New Roman')
% set(gca, 'FontSize', 18)
% set([hXLabel, hYLabel], 'FontSize', 18, 'FontWeight' ,'normal')
% % set(hTitle, 'FontSize', 18, 'FontWeight' ,'bold')
% % ����ͼ��
% h=legend('Error','$Boundary$','NumColumns',2,'interpreter','latex');
% set(h,'FontName','Times New Roman','FontSize',13,'FontWeight','normal');
% set(gcf,'Units','centimeter','Position',[4 4 18 12]);
% grid on;


% figure(4)
% % plot(state_output.time, state_output.signals.values(:,1),'sk-.','LineWidth',2,'MarkerSize',6,'MarkerIndices',maker_idx);
% plot(out.t, out.y1,'LineWidth',2);
% 
% hold on;
% % set(gcf,'Units','centimeter','Position',[5 5 18 14]);
% 
% hXLabel = xlabel('Time (sec)');
% hYLabel = ylabel('The sampling state $x_i(t_k)$','interpreter','latex');
% set(gca, 'Box', 'on', ...                                        % ��
%         'LineWidth',0.5, ...
%         'XGrid', 'off', 'YGrid', 'off', ...                      % ����
%         'TickDir', 'in', 'TickLength', [.015 .015], ...          % �̶�
%         'XMinorTick', 'on', 'YMinorTick', 'on', ...              % С�̶�
%         'XColor', [.1 .1 .1],  'YColor',[.1 .1 .1],...           % ��������ɫ
%         'XTick', 0:1:4,...                                    % �������̶ȡ���Χ
%         'XLim', [0 4],...
%         'YTick', -3:2:9,...
%         'YLim', [-3 9]);
% % �����������������
% set(gca, 'FontName', 'Times New Roman')
% set([hXLabel, hYLabel], 'FontName','Times New Roman')
% set(gca, 'FontSize', 18)
% set([hXLabel, hYLabel], 'FontSize', 18, 'FontWeight' ,'normal')
% % set(hTitle, 'FontSize', 18, 'FontWeight' ,'bold')
% % ����ͼ��
% h=legend('$x_1(t_k)$','$x_2(t_k)$','$x_3(t_k)$','$x_4(t_k)$','$x_5(t_k)$','$x_6(t_k)$','$x_7(t_k)$',...
%     '$x_8(t_k)$','NumColumns',2,'interpreter','latex');
% set(h,'FontName','Times New Roman','FontSize',13,'FontWeight','normal');
% set(gcf,'Units','centimeter','Position',[4 4 22 10]);
% grid on;
