%%%%% Jiangfeng Yue %%%%% 
%%%%%    2025.08    %%%%% 
% Title "Secure Flocking Dynamics of Swarms Over Cooperative-Antagonistic Networks"

% Initial states
intial_x1 = ((randn (1,24)*10)+10)/5;
intial_x2 = ((randn (1,24)*10)+10)/5;

intial_v1 = (randn (1,24)*2);
intial_v2 = (randn (1,24)*2);

% The parameters are randomly selected. They may not necessarily trigger the obstacle avoidance function. 
% The position of the obstacles can be modified according to the actual simulation results.